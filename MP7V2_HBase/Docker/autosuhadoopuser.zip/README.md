# Grader MP7 - HBase
This is the docker-based autograder for MP7 - HBase.

## Log
Last updated by Vinith Krishnan (vinithk2@illinois.edu)

## How to build the autograder

Git pull this whole repository and run

```
zip -r mp7grader.zip .
```

## How to grade submission

Download the Coursera Command Line tool and set up the environment via
```
https://github.com/coursera/coursera_autograder
```
More info can be found in:
```
https://github.com/coursera/programming-assignments-demo
```

## How to upload it to Coursera
run
```
coursera_autograder upload $PATH_TO_IMAGE_ZIP_FILE $COURSE_OR_BRANCH_ID $ITEM_ID $PART_ID

```
Specifically you may run the command:
```
coursera_autograder upload ./mp7grader.zip 0VdvRaY-Eeajiw6E9qqC5g VyhWo bUwff

```

Note: Above command may not run if the ID's change. You may find current ID's by following the instructions presented [here](https://github.com/coursera/coursera_autograder#upload) .

