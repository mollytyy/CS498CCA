import happybase as hb

conn = hb.Connection()
# A row looks like this:
# ('row3', {'professional:xp': '30', 'personal:power': 'eat', 'personal:hero': 'no', 
# 'custom:color': 'yellow', 'professional:name': 'bananaman'})
table = conn.table('powers')
while True:
  try:
    for row in table.scan():
      color = row[1]['custom:color']
      name = row[1]['professional:name']
      for row1 in table.scan():
        color1 = row1[1]['custom:color']
        name1 = row1[1]['professional:name']
        if color == color1 and name != name1:
          print('{}, {}, {}, {}, {}'.format(name, row[1]['personal:power'], 
            name1, row1[1]['personal:power'], color))
    break
  except Exception as e:
    if "org.apache.hadoop.hbase.DoNotRetryIOException" in e.message:
      connection.open()
    else:
      print e
      quit()
      
conn.close()

