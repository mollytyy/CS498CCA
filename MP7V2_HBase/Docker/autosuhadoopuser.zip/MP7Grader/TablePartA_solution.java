import java.io.IOException;

import org.apache.hadoop.conf.Configuration;

import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;

import org.apache.hadoop.hbase.TableName;

import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;

import org.apache.hadoop.hbase.util.Bytes;

public class TablePartA_solution{

   public static void main(String[] args) throws IOException {

	//TODO
	Configuration config = HBaseConfiguration.create();
	HBaseAdmin admin = new HBaseAdmin(config);
	HTableDescriptor tableDescriptor = new HTableDescriptor(TableName.valueOf("powers"));

	tableDescriptor.addFamily(new HColumnDescriptor("personal"));
	tableDescriptor.addFamily(new HColumnDescriptor("professional"));
	tableDescriptor.addFamily(new HColumnDescriptor("custom"));

	admin.createTable(tableDescriptor);

	HTable hTable = new HTable(config, "powers");
	Put p1 = new Put(Bytes.toBytes("row1"));
	p1.add(Bytes.toBytes("personal"), Bytes.toBytes("hero"), null);
	p1.add(Bytes.toBytes("personal"), Bytes.toBytes("power"), null);
	p1.add(Bytes.toBytes("professional"), Bytes.toBytes("name"), null);
	p1.add(Bytes.toBytes("professional"), Bytes.toBytes("xp"), null);
	p1.add(Bytes.toBytes("custom"), Bytes.toBytes("color"), null);
	hTable.put(p1);
	//MYCODE
	// System.out.println("Created table powers");  
	hTable.close();
	


	//TODO
	HTableDescriptor tableDescriptor0 = new HTableDescriptor(TableName.valueOf("food"));

	tableDescriptor0.addFamily(new HColumnDescriptor("nutrition"));
	tableDescriptor0.addFamily(new HColumnDescriptor("taste"));

	admin.createTable(tableDescriptor0);

	HTable hTable0 = new HTable(config, "food");
	Put p2 = new Put(Bytes.toBytes("row1"));
	p2.add(Bytes.toBytes("nutrition"), Bytes.toBytes("calories"), null);
	p2.add(Bytes.toBytes("nutrition"), Bytes.toBytes("fat"), null);
	p2.add(Bytes.toBytes("nutrition"), Bytes.toBytes("protein"), null);
	p2.add(Bytes.toBytes("nutrition"), Bytes.toBytes("sugar"), null);
	p2.add(Bytes.toBytes("taste"), Bytes.toBytes("taste"), null);
	hTable0.put(p2);
	//MYCODE
	// System.out.println("Created table food");  
	hTable0.close();
   }
}

