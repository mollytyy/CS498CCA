import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileReader;

public class PrintGrade {
	public static void main(String[] args) {
		double finalFractionalScore=0.0;

		String[] parts = {"A", "B", "C", "D", "E", "F", "G"};
		String[] grade = new String[7];
		for (int i=0; i<args.length; i++){
			grade[i] = "Part " + parts[i] + ": ";
			//cannot add '\t' here
			// grade += "\t";
			grade[i] += args[i];
			//cannot add '\n' here
			// grade += "\n";
			//if the output starts with "Congratulations"
			if (args[i].charAt(0)=='C'){
                if(i < 4)
				    finalFractionalScore += 0.1;
                else
                    finalFractionalScore += 0.2;
			} else {
				// If the output is wrong
				// add the stdout/err to 'grade' then print it out in JSON
				String outputFileName = "Part" + parts[i] + ".err";
				try (BufferedReader br = new BufferedReader(new FileReader(outputFileName))) {
   					String line = null;
   					while ((line = br.readLine()) != null) {
   						line = line.replaceAll("[^a-zA-Z0-9]+","_");
       					grade[i] += line + "\\n";
   					}
				} catch (IOException e){
					e.printStackTrace();
				}
			}
			if(i != 6){
				grade[i] += ";\\n";
			}else{
				grade[i] += "";
			}
		}
		String feedbackSum = "\"";
		for (String s : grade){
			feedbackSum += s;
		}
        feedbackSum += "\"";
		
		String jsonOutput = "{" + "\"fractionalScore\":" + finalFractionalScore + ",  " 
			+ "\"feedback\": " + feedbackSum + "}";
		
		System.out.println(jsonOutput);
	}
}
