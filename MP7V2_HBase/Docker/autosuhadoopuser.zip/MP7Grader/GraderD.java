import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileReader;

public class GraderD {
	public static void main(String[] args) {
		// Point penalty for each failing test case. This means if more than 5 test cases fail,

		// Number of test cases failed.
		int numTestCasesFailed = 0;


		String feedback;
		try {
			BufferedReader assignmentSolution = new BufferedReader(new FileReader(args[0]));
			BufferedReader learnerSolution = new BufferedReader(new FileReader(args[1]));

			String input;
			String output;

			for (input = assignmentSolution.readLine(), output = learnerSolution.readLine();
				input != null && output != null;
				input = assignmentSolution.readLine(), output = learnerSolution.readLine()) {
				if (!input.equals(output)) {
					numTestCasesFailed++;
				}
			}

			if (input != null || output != null) {
				feedback = "The_scan_of_your_table_is_incorrect.";
			} else if (numTestCasesFailed > 0) {

				feedback = "The_scan_of_your_table_is_incorrect.";
			} else {
				feedback = "Congrats!_Tables_are_correct!";
			}

			assignmentSolution.close();
			learnerSolution.close();

		} catch(IOException io) {
			System.err.println("Got_an_exception!");
			System.err.println(io.getMessage());
			io.printStackTrace(System.err);
			feedback = io.getMessage();
		}
	
		// Construct jsonOutput in the format expected by Coursera's infrastructure.
		String jsonOutput = feedback;
		System.out.println(jsonOutput);
	}
}
