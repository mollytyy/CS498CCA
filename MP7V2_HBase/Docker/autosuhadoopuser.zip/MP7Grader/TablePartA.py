import happybase as hb

conn = hb.Connection()

cf = {
    'personal': dict(),
    'professional': dict(),
    'custom':dict()
}

conn.create_table('powers', cf)

cf = {
    'nutrition': dict(),
    'taste': dict()
}

conn.create_table('food', cf)

conn.close()

