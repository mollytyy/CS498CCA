import java.io.IOException;

import org.apache.hadoop.conf.Configuration;

import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;

import org.apache.hadoop.hbase.TableName;

import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Get;


import org.apache.hadoop.hbase.util.Bytes;

public class TablePartD_solution{

   public static void main(String[] args) throws IOException {

	//TODO   
	Configuration conf = HBaseConfiguration.create();
	HTable table = new HTable(conf, "powers");

	Get g = new Get(Bytes.toBytes("row1"));
	Result result = table.get(g);
	byte [] herol = result.getValue(Bytes.toBytes("personal"),Bytes.toBytes("hero"));
	byte [] powerl = result.getValue(Bytes.toBytes("personal"),Bytes.toBytes("power"));
	byte [] namel = result.getValue(Bytes.toBytes("professional"),Bytes.toBytes("name"));
	byte [] xpl = result.getValue(Bytes.toBytes("professional"),Bytes.toBytes("xp"));
	byte [] colorl = result.getValue(Bytes.toBytes("custom"),Bytes.toBytes("color"));
	String hero = Bytes.toString(herol);
	String power = Bytes.toString(powerl);
	String name = Bytes.toString(namel);
	String xp = Bytes.toString(xpl);
	String color = Bytes.toString(colorl);
	System.out.println("hero: "+hero+", power: "+power+", name: "+name+", xp: "+xp+", color: "+color);

	 g = new Get(Bytes.toBytes("row19"));
	 result = table.get(g);
	 herol = result.getValue(Bytes.toBytes("personal"),Bytes.toBytes("hero"));
	 colorl = result.getValue(Bytes.toBytes("custom"),Bytes.toBytes("color"));
	 hero = Bytes.toString(herol);
	 color = Bytes.toString(colorl);
	System.out.println("hero: "+hero+", color: "+color);

	g = new Get(Bytes.toBytes("row1"));
	result = table.get(g);
	herol = result.getValue(Bytes.toBytes("personal"),Bytes.toBytes("hero"));
	namel = result.getValue(Bytes.toBytes("professional"),Bytes.toBytes("name"));
	colorl = result.getValue(Bytes.toBytes("custom"),Bytes.toBytes("color"));
	hero = Bytes.toString(herol);
	name = Bytes.toString(namel);
	color = Bytes.toString(colorl);
	System.out.println("hero: "+hero+", name: "+name+", color: "+color);

	table.close();
   }
}

