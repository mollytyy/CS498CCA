// Input 1: Name of file containing solutions
// Input 2: Name of the file where output from learner's program is  stored.

// `Grader` compares the two files and prints 'fractionalScore' and 'feedback' based on whether the two files match or not.

// example: If files match exactly, the output is - {"fractionalScore": 1.0, "feedback": "Congrats! All test cases passed!"}

import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileReader;

public class GraderF {
	public static void main(String[] args) {
		// Point penalty for each failing test case. This means if more than 5 test cases fail,

		// Number of test cases failed.
		int numTestCasesFailed = 0;
		int lineCount = 0;


		String feedback;
		try {
			BufferedReader assignmentSolution = new BufferedReader(new FileReader(args[0]));
			BufferedReader learnerSolution = new BufferedReader(new FileReader(args[1]));

			String input;
			String output;

			for (input = assignmentSolution.readLine(), output = learnerSolution.readLine();
				input != null && output != null;
				input = assignmentSolution.readLine(), output = learnerSolution.readLine()) {
				if (!input.equals(output)) {
					numTestCasesFailed++;
				}
				lineCount++;
			}

			if (input != null || output != null || lineCount != 56) {
				feedback = "Invalid_output.The_number_of_lines_produced_by_your_code_is_not_valid.";
			} else if (numTestCasesFailed > 0) {

				feedback = "Your_output_contains:_" + numTestCasesFailed + "_incorrect_lines_in_our_test.Please_try_again!";
			} else {
				feedback = "Congrats!_All_lines_are_correct!";
			}

			assignmentSolution.close();
			learnerSolution.close();

		} catch(IOException io) {
			System.err.println("Got_an_exception!");
			System.err.println(io.getMessage());
			io.printStackTrace(System.err);
			feedback = io.getMessage();
		}
	
		// Construct jsonOutput in the format expected by Coursera's infrastructure.
		String jsonOutput = feedback;
		System.out.println(jsonOutput);
	}
}
