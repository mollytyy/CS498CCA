import java.io.IOException;

import org.apache.hadoop.conf.Configuration;

import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;

import org.apache.hadoop.hbase.TableName;

import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;

import org.apache.hadoop.hbase.util.Bytes;

public class TablePartF_solution{

   public static void main(String[] args) throws IOException {

	//TODO      
	Configuration config = HBaseConfiguration.create();
	HTable table = new HTable(config, "powers");
	Scan scan = new Scan();
	scan.addColumn(Bytes.toBytes("personal"), Bytes.toBytes("hero"));
	scan.addColumn(Bytes.toBytes("personal"), Bytes.toBytes("power"));
	scan.addColumn(Bytes.toBytes("professional"), Bytes.toBytes("name"));
	scan.addColumn(Bytes.toBytes("professional"), Bytes.toBytes("xp"));
	scan.addColumn(Bytes.toBytes("custom"), Bytes.toBytes("color"));

	ResultScanner scanner = table.getScanner(scan);
	for (Result result = scanner.next(); result != null; result = scanner.next()){
		byte [] namel = result.getValue(Bytes.toBytes("professional"),Bytes.toBytes("name"));
		byte [] powerl = result.getValue(Bytes.toBytes("personal"),Bytes.toBytes("power"));
		byte [] colorl = result.getValue(Bytes.toBytes("custom"),Bytes.toBytes("color"));
		String name = Bytes.toString(namel);
		String power = Bytes.toString(powerl);
		String color = Bytes.toString(colorl);
		ResultScanner scanner1 = table.getScanner(scan);
		for(Result result1 = scanner1.next(); result1 != null; result1 = scanner1.next()){
			byte [] namel1 = result1.getValue(Bytes.toBytes("professional"),Bytes.toBytes("name"));
			byte [] powerl1 = result1.getValue(Bytes.toBytes("personal"),Bytes.toBytes("power"));
			byte [] colorl1 = result1.getValue(Bytes.toBytes("custom"),Bytes.toBytes("color"));
			String name1 = Bytes.toString(namel1);
			String power1 = Bytes.toString(powerl1);
			String color1 = Bytes.toString(colorl1);
			if((color.equals(color1)) && (!name.equals(name1)))
				System.out.println(name + ", " + power + ", " + name1 + ", " + power1 + ", "+color);
		}
	}
	scanner.close();

	table.close();
   }
}