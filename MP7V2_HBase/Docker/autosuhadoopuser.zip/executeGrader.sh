#! /bin/bash

# Coursera deletes all environment variables set inside 'Dockerfile'. If any environment varables
# need to be set, they must be set inside a wrapper bash script.
export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-amd64


echo "--------------- autosu" 1>&2
autosuhadoopuser 1>&2
sleep 2

echo "--------------- autohostfix" 1>&2
autosu autofixhosts hadooppass  1>&2
sleep 2

echo "whoami: " 1>&2
whoami 1>&2
echo "hostname: " 1>&2
hostname 1>&2
echo 1>&2

echo "vvvvvvvvvvvvvvvvvvvvv /etc/hosts" 1>&2
cat /etc/hosts 1>&2
echo "^^^^^^^^^^^^^^^^^^^^^ /etc/hosts" 1>&2
echo 1>&2

echo "vvvvvvvvvvvvvvvvvvvvv /etc/passwd" 1>&2
cat /etc/passwd 1>&2
echo "^^^^^^^^^^^^^^^^^^^^^ /etc/hosts" 1>&2
echo 1>&2

export ZOO_LOG_DIR=/usr/local/zookeeper/log/

export HBASE_HOME=/usr/local/hbase
export PATH="/usr/local/hbase/bin:${PATH}"

# Switch to the grader directory
cd /grader

# Unique Part Ids for each assignment part that will be graded using this grader.
# These are exposed in Coursera's authoring tools for each programming assignment part.
MP0_ID="r3uwK"
MP2_ID="0YSbM"
MP7_ID="bUwff"
MP6_ID="X2zSv"
MP6_ID_P2="MN5gq"

# Parse the command line arguments supplied by Coursera.
while [[ $# > 1 ]]
  do
    key="$1"
    case $key in
      partId)
        # Unique Id associated with the part which is being graded.
        PARTID="$2"
        echo $PARTID
        shift
        ;;
      filename)
        # Original filename as uploaded by the learner.
        # Note: Coursera 'always' renames the submission to the suggested filename as specified within the authoring UI.
        # This is an optional parameter and most of the graders don't end up using it.
        ORIGINAL_FILENAME="$2"
        shift
        ;;
    esac
  shift
done

if [ "bUwff" == "$MP7_ID" ]; then
  echo "VVVVVVVVVVVVVVVVVVVVV start-zookeeper" 1>&2
  /usr/local/zookeeper/bin/zkServer.sh start 1>&2
  echo "^^^^^^^^^^^^^^^^^^^^^ start-zookeeper" 1>&2
  echo 1>&2
  sleep 5

  echo "VVVVVVVVVVVVVVVVVVVVV start-hbase" 1>&2
  /usr/local/hbase/bin/start-hbase.sh 1>&2
  echo "^^^^^^^^^^^^^^^^^^^^^ start-hbase" 1>&2
  echo 1>&2
  sleep 5

  #ls -l /usr/local/hbase/logs 1>&2

  echo "-------------------------- logs of hbase below ----------------------" 1>&2
  cat /usr/local/hbase/logs/*master*.log 1>&2
  echo 1>&2

  echo "-------------------------- logs of regionserver below ----------------------" 1>&2
  cat /usr/local/hbase/logs/*regionserver*.log 1>&2
  echo 1>&2

  echo "VVVVVVVVVVVVVVVVVVVVV netstat" 1>&2
  netstat -tln 1>&2
  echo "^^^^^^^^^^^^^^^^^^^^^ netstat" 1>&2
  echo 1>&2

  echo "VVVVVVVVVVVVVVVVVVVVV jps" 1>&2
  jps 1>&2
  echo "^^^^^^^^^^^^^^^^^^^^^ jps" 1>&2
  echo 1>&2

  GRADER_DIRECTORY=MP7Grader

  unzip -qq /shared/submission/* -d .
  mv MP7Grader/input.csv ./input.csv

  if [ ! $? -eq 0 ]; then
    echo "{ \"fractionalScore\": 0.0, \"feedback\":\"Cannot unzip your file. Please make sure that you are submitting a .zip file.\" }" > /shared/feedback.json
    exit 0
  fi

  if [ -e MP7/TablePartA.java ]; then
    file_ext="java"
  elif [ -e MP7/TablePartA.py ]; then
    file_ext="py"
  else
    echo "{ \"fractionalScore\":0.0, \"feedback\":\"If you are submitting java files, please make sure you include all java files needed; If you are submitting python files, please make sure you include all python files needed. We could not find neither TablePartA.java nor TablePartA.py in your MP7 folder.\" }" > /shared/feedback.json
    exit 0
  fi


  javac "$GRADER_DIRECTORY"/Grader.java -d .
  javac "$GRADER_DIRECTORY"/GraderA.java -d .
  javac "$GRADER_DIRECTORY"/GraderC.java -d .
  javac "$GRADER_DIRECTORY"/GraderD.java -d .
  javac "$GRADER_DIRECTORY"/GraderE.java -d .
  javac "$GRADER_DIRECTORY"/GraderF.java -d .
  javac "$GRADER_DIRECTORY"/GraderG.java -d .
  javac -d . "$GRADER_DIRECTORY"/PrintGrade.java

  pyth="py"
  jav="java"
  if [ $file_ext == "$jav" ]; then
    export CLASSPATH=$(hbase classpath)
    export CLASSPATH="/grader:${CLASSPATH}"
    export CLASSPATH="/grader/MP7Grader:${CLASSPATH}"

    javac -d . MP7/TablePartA.java
    java TablePartA
    javac -d . "$GRADER_DIRECTORY"/TablePartB_solution.java
    java TablePartB_solution 1> TablePartA_submission.txt 2>PartA.err
    partA_grade="$(java GraderA ./MP7Grader/list.txt ./TablePartA_submission.txt)"

    javac -d . MP7/TablePartB.java
    java TablePartB 1> TablePartB_submission.txt 2>PartB.err
    partB_grade="$(java Grader ./MP7Grader/list.txt ./TablePartB_submission.txt)"

    javac -d . MP7/TablePartC.java
    java TablePartC
    javac -d . "$GRADER_DIRECTORY"/TablePartD_solution.java
    java TablePartD_solution 1> TablePartC_submission.txt 2>PartC.err
    partC_grade="$(java GraderC ./MP7Grader/content.txt ./TablePartC_submission.txt)"


    javac -d . MP7/TablePartD.java
    java TablePartD 1> TablePartD_submission.txt 2>PartD.err
    partD_grade="$(java Grader ./MP7Grader/content.txt ./TablePartD_submission.txt)"

    javac -d . MP7/TablePartE.java
    java TablePartE 1> TablePartE_submission.txt 2>PartE.err
    javac -d . "$GRADER_DIRECTORY"/TablePartE_solution.java
    java TablePartE_solution 1> TablePartE_solution.txt
    partE_grade="$(java GraderE ./TablePartE_solution.txt ./TablePartE_submission.txt)"

    javac -d . MP7/TablePartF.java
    java TablePartF 1> TablePartF_submission.txt 2>PartF.err
    javac -d . "$GRADER_DIRECTORY"/TablePartF_solution.java
    java TablePartF_solution 1> TablePartF_solution.txt
    partF_grade="$(java GraderF ./TablePartF_solution.txt ./TablePartF_submission.txt)"
	
	/usr/local/phoenix/bin/sqlline.py localhost:2181:/hbase-unsecure MP7/phoenix.sql > TablePartG_submission.txt
	/usr/local/phoenix/bin/sqlline.py localhost:2181:/hbase-unsecure "$GRADER_DIRECTORY"/phoenix.sql > TablePartG_solution.txt
	#partG_grade="$(java GraderG ./TablePartG_solution.txt ./TablePartG_submission.txt)"
	partG_grade="$(cat ./TablePartG_solution.txt)"

    Graderjavaoutput="$(java PrintGrade $partA_grade $partB_grade $partC_grade $partD_grade $partE_grade $partF_grade $partG_grade)"
    echo "$Graderjavaoutput" >  /shared/feedback.json

  elif [ $file_ext == "$pyth" ]; then
    echo "----------------- starting hbase thrift" 1>&2
    hbase thrift start 1>&2 &
    sleep 11
    python MP7/TablePartA.py
    python "$GRADER_DIRECTORY"/TablePartB.py 1> TablePartA_submission.txt 2>PartA.err
    partA_grade="$(java GraderA ./MP7Grader/listpy.txt ./TablePartA_submission.txt)"
    
    python MP7/TablePartB.py 1> TablePartB_submission.txt 2>PartB.err
    partB_grade="$(java Grader ./MP7Grader/listpy.txt ./TablePartB_submission.txt)"

    python MP7/TablePartC.py
    python "$GRADER_DIRECTORY"/TablePartD.py 1> TablePartC_submission.txt 2>PartC.err
    partC_grade="$(java GraderC ./MP7Grader/contentpy.txt ./TablePartC_submission.txt)"
    
    python MP7/TablePartD.py 1> TablePartD_submission.txt 2>PartD.err
    partD_grade="$(java Grader ./MP7Grader/contentpy.txt ./TablePartD_submission.txt)"

    # python MP7/TablePartE.py 1> TablePartE_submission.txt
    # python "$GRADER_DIRECTORY"/TablePartE.py 1> TablePartE_solution.txt
    
    python MP7/TablePartE.py 1> TablePartE_submission.txt 2>PartE.err
    python "$GRADER_DIRECTORY"/TablePartE.py 1> TablePartE_solution.txt
    partE_grade="$(java GraderE ./TablePartE_solution.txt ./TablePartE_submission.txt)"

    python MP7/TablePartF.py 1> TablePartF_solution.txt 2>PartF.err
    python "$GRADER_DIRECTORY"/TablePartF.py 1> TablePartF_submission.txt
    partF_grade="$(java GraderF ./TablePartF_solution.txt ./TablePartF_submission.txt)"
	
	/usr/local/phoenix/bin/sqlline.py localhost:2181:/hbase-unsecure MP7/phoenix.sql > TablePartG_submission.txt
	/usr/local/phoenix/bin/sqlline.py localhost:2181:/hbase-unsecure "$GRADER_DIRECTORY"/phoenix.sql > TablePartG_solution.txt
	#partG_grade="$(java GraderG ./TablePartG_solution.txt ./TablePartG_submission.txt)"
	partG_grade="$(cat ./TablePartG_solution.txt)"

    Graderoutput="$(java PrintGrade $partA_grade $partB_grade $partC_grade $partD_grade $partE_grade $partF_grade $partG_grade)"
    echo "$Graderoutput" > /shared/feedback.json

  fi

elif [ "$PARTID" == "$MP6_ID_P2" ]; then
  #autohbase
  GRADER_DIRECTORY=MP7Grader

  unzip -qq /shared/submission/* -d .
  mv MP7Grader/input.csv ./input.csv
  # unzip -qq submission/* -d .
  # unzip MP2.zip -d .

  if [ ! $? -eq 0 ]; then
    echo "{ \"fractionalScore\": 0.0, \"feedback\":\"Cannot unzip your file. Please make sure that you are submitting a .zip file.\" }" > /shared/feedback.json
    exit 0
  fi

  if [ -e MP7/TablePartA.java ]; then
    file_ext="java"
  elif [ -e MP7/TablePartA.py ]; then
    file_ext="py"
  else
    echo "{ \"fractionalScore\":0.0, \"feedback\":\"If you are submitting java files, please make sure you include all java files needed; If you are submitting python files, please make sure you include all python files needed. We could not find neither TablePartA.java nor TablePartA.py in your MP7 folder.\" }" > executeGrader.sh
    exit 0
  fi


  javac "$GRADER_DIRECTORY"/Grader.java -d .
  javac "$GRADER_DIRECTORY"/GraderA.java -d .
  javac "$GRADER_DIRECTORY"/GraderC.java -d .
  javac "$GRADER_DIRECTORY"/GraderD.java -d .
  javac "$GRADER_DIRECTORY"/GraderE.java -d .
  javac "$GRADER_DIRECTORY"/GraderF.java -d .
  javac "$GRADER_DIRECTORY"/GraderG.java -d .
  javac -d . "$GRADER_DIRECTORY"/PrintGrade.java

  echo "VVVVVVVVVVVVVVVVVVVVV start-zookeeper" 1>&2
  /usr/local/zookeeper/bin/zkServer.sh start 1>&2
  #autohbasezookeeper 1>&2
  echo "^^^^^^^^^^^^^^^^^^^^^ start-zookeeper" 1>&2
  echo 1>&2
  sleep 5

  # we can possibly use autohbase instead of the next line
  #echo "--------------- autohbase" 1>&2
  #autohbase 1>&2

  echo "VVVVVVVVVVVVVVVVVVVVV start-hbase" 1>&2
  #/usr/local/hbase/bin/start-hbase.sh 1>&2
  /usr/local/hbase/bin/start-hbase.sh 1>&2
  echo "^^^^^^^^^^^^^^^^^^^^^ start-hbase" 1>&2
  echo 1>&2
  sleep 5

  ls -l /usr/local/hbase/logs 1>&2

  echo "-------------------------- logs of hbase below ----------------------" 1>&2
  cat /usr/local/hbase/logs/*master*.log 1>&2
  echo 1>&2

  echo "-------------------------- logs of regionserver below ----------------------" 1>&2
  cat /usr/local/hbase/logs/*regionserver*.log 1>&2
  echo 1>&2

  #/usr/local/hbase/bin/hbase thrift start &
  #sleep 3

  echo "VVVVVVVVVVVVVVVVVVVVV autonetstat" 1>&2
  #autonetstat 1>&2
  netstat -tln 1>&2
  echo "^^^^^^^^^^^^^^^^^^^^^ autonetstat" 1>&2
  echo 1>&2

  echo "VVVVVVVVVVVVVVVVVVVVV jps" 1>&2
  #autonetstat 1>&2
  jps 1>&2
  echo "^^^^^^^^^^^^^^^^^^^^^ jps" 1>&2
  echo 1>&2

  pyth="py"
  jav="java"
  if [ $file_ext == "$jav" ]; then
    export CLASSPATH=$(hbase classpath)
    export CLASSPATH="/grader:${CLASSPATH}"
    export CLASSPATH="/grader/MP7Grader:${CLASSPATH}"

    javac -d . MP7/TablePartA.java
    java TablePartA
    javac -d . "$GRADER_DIRECTORY"/TablePartB_solution.java
    java TablePartB_solution 1> TablePartA_submission.txt 2>PartA.err
    partA_grade="$(java GraderA ./MP7Grader/list.txt ./TablePartA_submission.txt)"

    javac -d . MP7/TablePartB.java
    java TablePartB 1> TablePartB_submission.txt 2>PartB.err
    partB_grade="$(java Grader ./MP7Grader/list.txt ./TablePartB_submission.txt)"

    javac -d . MP7/TablePartC.java
    java TablePartC
    javac -d . "$GRADER_DIRECTORY"/TablePartD_solution.java
    java TablePartD_solution 1> TablePartC_submission.txt 2>PartC.err
    partC_grade="$(java GraderC ./MP7Grader/content.txt ./TablePartC_submission.txt)"


    javac -d . MP7/TablePartD.java
    java TablePartD 1> TablePartD_submission.txt 2>PartD.err
    partD_grade="$(java Grader ./MP7Grader/content.txt ./TablePartD_submission.txt)"

    javac -d . MP7/TablePartE.java
    java TablePartE 1> TablePartE_submission.txt 2>PartE.err
    javac -d . "$GRADER_DIRECTORY"/TablePartE_solution.java
    java TablePartE_solution 1> TablePartE_solution.txt
    partE_grade="$(java GraderE ./TablePartE_solution.txt ./TablePartE_submission.txt)"

    javac -d . MP7/TablePartF.java
    java TablePartF 1> TablePartF_submission.txt 2>PartF.err
    javac -d . "$GRADER_DIRECTORY"/TablePartF_solution.java
    java TablePartF_solution 1> TablePartF_solution.txt
    partF_grade="$(java GraderF ./TablePartF_solution.txt ./TablePartF_submission.txt)"
	
	/usr/local/phoenix/bin/sqlline.py localhost:2181:/hbase-unsecure MP7/phoenix.sql > TablePartG_submission.txt
	/usr/local/phoenix/bin/sqlline.py localhost:2181:/hbase-unsecure "$GRADER_DIRECTORY"/phoenix.sql > TablePartG_solution.txt
	#partG_grade="$(java GraderG ./TablePartG_solution.txt ./TablePartG_submission.txt)"
	partG_grade="$(cat ./TablePartG_solution.txt)"

    java PrintGrade $partA_grade $partB_grade $partC_grade $partD_grade $partE_grade $partF_grade $partG_grade

  elif [ $file_ext == "$pyth" ]; then
    echo "----------------- starting hbase thrift" 1>&2
    hbase thrift start 1>&2 &
    sleep 11
    python MP7/TablePartA.py
    python "$GRADER_DIRECTORY"/TablePartB.py 1> TablePartA_submission.txt 2>PartA.err
    partA_grade="$(java GraderA ./MP7Grader/listpy.txt ./TablePartA_submission.txt)"
    
    python MP7/TablePartB.py 1> TablePartB_submission.txt 2>PartB.err
    partB_grade="$(java Grader ./MP7Grader/listpy.txt ./TablePartB_submission.txt)"

    python MP7/TablePartC.py
    python "$GRADER_DIRECTORY"/TablePartD.py 1> TablePartC_submission.txt 2>PartC.err
    partC_grade="$(java GraderC ./MP7Grader/contentpy.txt ./TablePartC_submission.txt)"
    
    python MP7/TablePartD.py 1> TablePartD_submission.txt 2>PartD.err
    partD_grade="$(java Grader ./MP7Grader/contentpy.txt ./TablePartD_submission.txt)"
    
    python MP7/TablePartE.py 1> TablePartE_submission.txt 2>PartE.err
    python "$GRADER_DIRECTORY"/TablePartE.py 1> TablePartE_solution.txt
    partE_grade="$(java GraderE ./TablePartE_solution.txt ./TablePartE_submission.txt)"

    python MP7/TablePartF.py 1> TablePartF_submission.txt 2>PartF.err
    python "$GRADER_DIRECTORY"/TablePartF.py 1> TablePartF_solution.txt
    partF_grade="$(java GraderF ./TablePartF_solution.txt ./TablePartF_submission.txt)"
	
	/usr/local/phoenix/bin/sqlline.py localhost:2181:/hbase-unsecure MP7/phoenix.sql > TablePartG_submission.txt
	/usr/local/phoenix/bin/sqlline.py localhost:2181:/hbase-unsecure "$GRADER_DIRECTORY"/phoenix.sql > TablePartG_solution.txt
	#partG_grade="$(java GraderG ./TablePartG_solution.txt ./TablePartG_submission.txt)"
	partG_grade="$(cat ./TablePartG_solution.txt)"

    java PrintGrade $partA_grade $partB_grade $partC_grade $partD_grade $partE_grade $partF_grade $partG_grade

  fi
else
  echo "PartId not matched." 2>&1
  exit 1
fi

# Compile Grader.java
# javac Grader.java

# Use Grader.java to compare learnerOutput.txt and solution.txt
# java Grader taOutput.txt learnerOutput.txt
